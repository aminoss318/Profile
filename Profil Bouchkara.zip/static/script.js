/* ===========================
   Profile Bouchkara
   script.js
=========================== */

// Loading Screen
window.addEventListener("load", () => {
    
    const loader = document.querySelector(".loader");
    
    setTimeout(() => {
        
        loader.style.opacity = "0";
        
        loader.style.pointerEvents = "none";
        
        setTimeout(() => {
            loader.style.display = "none";
        }, 1000);
        
    }, 2500);
    
});

// Type Writer

const text = "Welcome to Profile Bouchkara";

const welcome = document.getElementById("welcomeText");

let i = 0;

function typeWriter() {
    
    if (i < text.length) {
        
        welcome.innerHTML += text.charAt(i);
        
        i++;
        
        setTimeout(typeWriter, 80);
        
    }
    
}

typeWriter();


// Smooth Scroll

document.querySelectorAll('nav a').forEach(link => {
    
    link.addEventListener('click', function(e) {
        
        const href = this.getAttribute("href");
        
        if (href.startsWith("#")) {
            
            e.preventDefault();
            
            document.querySelector(href).scrollIntoView({
                
                behavior: "smooth"
                
            });
            
        }
        
    });
    
});


// Reveal Animation

const cards = document.querySelectorAll(".card");

const observer = new IntersectionObserver(entries => {
    
    entries.forEach(entry => {
        
        if (entry.isIntersecting) {
            
            entry.target.style.opacity = "1";
            
            entry.target.style.transform = "translateY(0px)";
            
        }
        
    });
    
});

cards.forEach(card => {
    
    card.style.opacity = "0";
    
    card.style.transform = "translateY(50px)";
    
    card.style.transition = ".7s";
    
    observer.observe(card);
    
});


// Floating Stars

for (let s = 0; s < 120; s++) {
    
    const star = document.createElement("span");
    
    star.innerHTML = "✦";
    
    star.style.position = "fixed";
    
    star.style.left = Math.random() * 100 + "%";
    
    star.style.top = Math.random() * 100 + "%";
    
    star.style.fontSize = (Math.random() * 8 + 5) + "px";
    
    star.style.color = "#00e5ff";
    
    star.style.opacity = Math.random();
    
    star.style.pointerEvents = "none";
    
    star.style.animation = `float ${Math.random()*6+5}s linear infinite`;
    
    document.body.appendChild(star);
    
}

const style = document.createElement("style");

style.innerHTML = `

@keyframes float{

0%{

transform:translateY(0px);

opacity:.2;

}

50%{

opacity:1;

}

100%{

transform:translateY(-80px);

opacity:.2;

}

}

`;

document.head.appendChild(style);


// Mouse Glow

const glow = document.createElement("div");

glow.style.width = "18px";
glow.style.height = "18px";
glow.style.borderRadius = "50%";
glow.style.position = "fixed";
glow.style.background = "#00e5ff";
glow.style.pointerEvents = "none";
glow.style.boxShadow = "0 0 25px #00e5ff";
glow.style.zIndex = "99999";

document.body.appendChild(glow);

document.addEventListener("mousemove", (e) => {
    
    glow.style.left = e.clientX - 9 + "px";
    glow.style.top = e.clientY - 9 + "px";
    
});


// Console

console.log("Welcome To Profile Bouchkara");